#!/usr/bin/env python3
"""Creativity Engine MCP — MEOK AI Labs. Bisociation, novelty scoring, QD archive, exploration."""
import json, os, random, math, hashlib
from datetime import datetime, timezone
from typing import Optional
from collections import defaultdict
from mcp.server.fastmcp import FastMCP

FREE_DAILY_LIMIT = 10
_usage = defaultdict(list)
def _rl(c="anon"):
    now = datetime.now(timezone.utc)
    _usage[c] = [t for t in _usage[c] if (now-t).total_seconds() < 86400]
    if len(_usage[c]) >= FREE_DAILY_LIMIT: return json.dumps({"error": f"Limit {FREE_DAILY_LIMIT}/day"})
    _usage[c].append(now); return None

mcp = FastMCP("creativity-engine", instructions="MEOK AI Labs — Creativity engine. Bisociation (Koestler), novelty scoring, quality-diversity archive, conceptual exploration.")

_qd_archive = []  # Quality-Diversity archive

DOMAINS = ["technology", "nature", "art", "science", "philosophy", "music", "mathematics", "literature", "cooking", "architecture", "psychology", "economics"]

@mcp.tool()
def find_bisociations(concept_a: str, concept_b: str, depth: int = 3) -> str:
    """Find creative bisociations between two concepts (Koestler's theory). Discovers hidden connections across domains."""
    if err := _rl(): return err
    bridges = []
    for i in range(depth):
        domain = random.choice(DOMAINS)
        bridge = {
            "bridge_domain": domain,
            "connection": f"In {domain}, '{concept_a}' and '{concept_b}' share the pattern of {random.choice(['transformation', 'recursion', 'emergence', 'tension', 'harmony', 'constraint', 'flow'])}",
            "novelty_score": round(random.uniform(0.3, 0.95), 2),
            "practical_application": f"Apply {domain} principles to combine {concept_a} + {concept_b} for novel solutions",
        }
        bridges.append(bridge)
    bridges.sort(key=lambda x: x["novelty_score"], reverse=True)
    return json.dumps({"concept_a": concept_a, "concept_b": concept_b, "bisociations": bridges,
        "highest_novelty": bridges[0]["novelty_score"], "recommended_bridge": bridges[0]["bridge_domain"]}, indent=2)

@mcp.tool()
def assess_creativity(idea: str) -> str:
    """Score an idea across 5 creativity dimensions: novelty, utility, surprise, elegance, feasibility."""
    if err := _rl(): return err
    words = idea.lower().split()
    scores = {
        "novelty": round(min(1.0, len(set(words)) / max(len(words), 1) + random.uniform(0, 0.3)), 2),
        "utility": round(random.uniform(0.3, 0.9), 2),
        "surprise": round(random.uniform(0.2, 0.8), 2),
        "elegance": round(random.uniform(0.3, 0.8), 2),
        "feasibility": round(random.uniform(0.4, 0.9), 2),
    }
    overall = round(sum(scores.values()) / len(scores), 2)
    return json.dumps({"idea": idea[:100], "scores": scores, "overall": overall,
        "classification": "breakthrough" if overall > 0.8 else "promising" if overall > 0.6 else "incremental" if overall > 0.4 else "needs_work",
        "recommendation": f"Strongest in {max(scores, key=scores.get)}. Improve {min(scores, key=scores.get)}."}, indent=2)

@mcp.tool()
def compute_novelty(description: str, domain: str = "general") -> str:
    """Compute novelty score by comparing against known solutions in the QD archive."""
    if err := _rl(): return err
    h = hashlib.md5(description.encode()).hexdigest()
    # Check archive for similar entries
    similar = [e for e in _qd_archive if e.get("domain") == domain]
    novelty = 0.9 if not similar else round(max(0.1, 1.0 - len(similar) * 0.1), 2)
    entry = {"id": h[:8], "description": description[:100], "domain": domain, "novelty": novelty, "timestamp": datetime.now(timezone.utc).isoformat()}
    _qd_archive.append(entry)
    return json.dumps({**entry, "archive_size": len(_qd_archive), "domain_entries": len(similar)}, indent=2)

@mcp.tool()
def suggest_exploration(current_domain: str, goal: str = "innovation") -> str:
    """Suggest unexplored conceptual territories for creative exploration."""
    if err := _rl(): return err
    adjacent = [d for d in DOMAINS if d != current_domain]
    random.shuffle(adjacent)
    suggestions = []
    for d in adjacent[:5]:
        suggestions.append({
            "domain": d,
            "connection_to_current": f"{current_domain} × {d}",
            "exploration_prompt": f"What if we applied {d} principles to {current_domain}? How would {goal} look through the lens of {d}?",
            "estimated_novelty": round(random.uniform(0.5, 0.95), 2),
        })
    suggestions.sort(key=lambda x: x["estimated_novelty"], reverse=True)
    return json.dumps({"current_domain": current_domain, "goal": goal, "suggestions": suggestions,
        "highest_potential": suggestions[0]["domain"]}, indent=2)

@mcp.tool()
def get_qd_archive_stats() -> str:
    """Get Quality-Diversity archive statistics."""
    domains = defaultdict(int)
    for e in _qd_archive: domains[e.get("domain", "unknown")] += 1
    avg_novelty = sum(e.get("novelty", 0) for e in _qd_archive) / max(len(_qd_archive), 1)
    return json.dumps({"total_entries": len(_qd_archive), "domains": dict(domains),
        "average_novelty": round(avg_novelty, 2), "unique_domains": len(domains)}, indent=2)

if __name__ == "__main__":
    mcp.run()
